Trabalho 2 de grafos
Autores: Pedro Demarchi Gomes e Leonarfo Stefan

Colore de maneira otima grafos cordais e distância-hereditários.
Primeiro eh feita uma LexBFS e eh armazenda a ordem em que os vertices foram percorridos. Essa ordem eh percorrida de maneira inversa, comecando pelo ultimo vertice percorrido ate o primeiro, atribuindo cores aos vertices, sendo que cada vertice deve ter uma cor diferente dos seus vizinhos.


